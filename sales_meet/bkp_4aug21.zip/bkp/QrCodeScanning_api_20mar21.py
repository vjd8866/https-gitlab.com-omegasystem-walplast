from odoo import http
from odoo.http import request
import json
import xmlrpc, xmlrpc.client
from odoo.addons.web.controllers.main import ensure_db, Session
from odoo.tools.translate import _
from datetime import datetime, timedelta, date


class QrCodeScanning(http.Controller):

    @http.route('/wmvdapi/push_qrcoupon', auth='user', methods=["POST"], type="json")
    def push_coupon(self, coupon, user_id, user_type, distributor_id=False):
        print("------------/wmvdapi/push_qrcoupon -----------", user_id)
        print "--------------------" , coupon, distributor_id, user_id, user_type
        resp = request.env['barcode.marketing.check'].sudo().check_mobile_coupon(coupon, user_id, user_type, distributor_id)
        print("fffffffffffffffffffffffffffffff", resp, type(resp))
        if isinstance(resp, str):
            return {'success': None, 'error': resp}
            
        else:
            return {'success': resp, 'error': None}


    @http.route('/wmvdapi/retailer_dashboard', auth='user', methods=["POST"], type="json")
    def retailer_dashboard(self, user_id, user_type):
        """ Amount yet to be Received From Distributor """
        print("------------/wmvdapi/retailer_dashboard -----------", user_id)
        if user_type == 'Retailer':
            pay_customer_domain = ['|',('user_id', '=', user_id),('user_id2', '=', user_id),
                        ('mobile_bool', '=', True),
                        ('retailer_scanned', '=', True),
                    ]
            received_from_distributor_domain = ['|',('user_id', '=', user_id),('user_id2', '=', user_id),
                        ('mobile_bool', '=', True),
                        ('retailer_scanned', '=', True),
                        '|',('distributor_paid_bool', '=', True),('distributor_paid_bool2', '=', True)
                    ]

            receive_from_distributor_domain = ['|',('user_id', '=', user_id),('user_id2', '=', user_id),
                        ('mobile_bool', '=', True),
                        ('retailer_scanned', '=', True),
                        '|',('distributor_paid_bool', '=', False),('distributor_paid_bool2', '=', False),
                    ]

            pay_customer_amount = [sum(x.amount for x in request.env['barcode.marketing.line'].sudo().search(receive_from_distributor_domain))]
            receive_from_distributor_amount = [sum(x.amount for x in request.env['barcode.marketing.line'].sudo().search(receive_from_distributor_domain))]
            received_from_distributor_amount = [sum(x.amount for x in request.env['barcode.marketing.line'].sudo().search(received_from_distributor_domain))]


            response = {'amount_paid' : pay_customer_amount or 0, 
                        'amount_received': receive_from_distributor_amount  or 0, 
                        'amount_yet_to_be_received': received_from_distributor_amount or 0, }

            return {'success': response, 'error': None}

    @http.route('/wmvdapi/today_scan_coupons', auth='user', methods=["POST"], type="json")
    def today_scan_coupons(self, user_id):
        """ Today Scans By User """
        print("------------/wmvdapi/today_scan_coupons -----------", user_id)
        data = {}
        today_scan_coupons= []
        domain = ['|',('user_id', '=', user_id),('user_id2', '=', user_id),'|',
                    ('updated_date', '=', date.today()),
                    ('scanned_date2', '=', date.today())
                ]
        coupon_scanned = request.env['barcode.marketing.line'].sudo().search(domain)
        if coupon_scanned:
            coupon_scanned_count = len(coupon_scanned)
            print("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa", coupon_scanned_count)

            for res in coupon_scanned:
                data = {
                        'coupon': res.name,
                        'date': res.updated_datetime or res.scanned_datetime2,
                        'distributor' : res.partner_id.name or res.partner_id2.name, 
                        'user' : res.user_id.name or res.user_id2.name, 
                        'amount' : res.amount,
                    }
                today_scan_coupons.append((data))

            response = {'count' : coupon_scanned_count, 'list': today_scan_coupons}

            return {'success': response, 'error': None}


    @http.route('/wmvdapi/all_scan_coupons', auth='user', methods=["POST"], type="json")
    def all_scan_coupons(self, user_id):
        """ All Scans By User """
        print("------------/wmvdapi/all_scan_coupons -----------", user_id)
        data = {}
        all_scan_coupons= []
        domain = ['|',('user_id', '=', user_id),('user_id2', '=', user_id)]
        coupon_scanned = request.env['barcode.marketing.line'].sudo().search(domain)

        for res in coupon_scanned:
            data = {
                    'coupon': res.name,
                    'date': res.updated_datetime or res.scanned_datetime2,
                    'distributor' : res.partner_id.name or res.partner_id2.name, 
                    'user' : res.user_id.name or res.user_id2.name, 
                    'amount' : res.amount,
                }
            all_scan_coupons.append((data))

        return {'success': all_scan_coupons, 'error': None}

    @http.route('/wmvdapi/get_distributor', methods=["POST"], type='json', auth='user')
    def get_partner(self, distributor_id=None):
        print("------------/wmvdapi/get_distributor -----------", distributor_id)
        domain = [('id', '=', distributor_id),('active', '=', True)]
        partner_rec = request.env['res.partner'].sudo().search(domain)

        if partner_rec :
            distributor_count = len(partner_rec)
            partner = []

            for rec in partner_rec:
                base_url = request.env['ir.config_parameter'].sudo().get_param('web.base.url')
                image_url_128 = base_url + '/web/image?' + 'model=res.partner&id=' + str(rec.id) + '&field=image'
                vals = {
                    'id': rec.id,
                    'name': rec.name,
                    'mobile': rec.mobile,
                    'email' : rec.email,
                    'image' : image_url_128,
                    'address' : ((rec.street + ', ') if rec.street else ' ' ) + \
                                ((rec.street2+ ', ') if rec.street2 else ' ' )  + \
                                ((rec.city + ', ') if rec.city else ' ' ) + \
                                ((rec.zip + ', ') if rec.zip else ' ' ) + \
                                ((rec.state_id.name + ', ') if rec.state_id else ' ' ) + \
                                ((rec.country_id.name + ', ') if rec.country_id else ' ' )

                }
                partner.append(vals)

            response = {'count' : distributor_count, 'list': partner}
            return {'success': response, 'error': None}
        else:
            return {'success': None, 'error':'Invalid Request'}

    @http.route('/wmvdapi/get_retailer', auth='user', methods=["POST"], type="json")
    def get_retailer(self, partner_id):
        """ All Retailers of Distributor """

        domain = [('wp_distributor_id', '=', partner_id),]
        partner_rec = request.env['res.partner'].sudo().search(domain)

        if partner_rec :
            partner = []
            retailer_count = len(partner_rec)
            for rec in partner_rec:
                base_url = request.env['ir.config_parameter'].sudo().get_param('web.base.url')
                image_url_128 = base_url + '/web/image?' + 'model=res.partner&id=' + str(rec.id) + '&field=image'
                vals = {
                    'id': rec.id,
                    'name': rec.name,
                    'mobile': rec.mobile,
                    'email' : rec.email,
                    'image' : image_url_128,
                    'address' : ((rec.street + ', ') if rec.street else ' ' ) + \
                                ((rec.street2+ ', ') if rec.street2 else ' ' )  + \
                                ((rec.city + ', ') if rec.city else ' ' ) + \
                                ((rec.zip + ', ') if rec.zip else ' ' ) + \
                                ((rec.state_id.name + ', ') if rec.state_id else ' ' ) + \
                                ((rec.country_id.name + ', ') if rec.country_id else ' ' )

                }
                partner.append(vals)

            response = {'count' : retailer_count, 'list': partner}
            return {'success': response, 'error': None}
        else:
            return {'success': None, 'error':'No Retailers Found'}


    @http.route('/wmvdapi/pay_customer', auth='user', methods=["POST"], type="json")
    def pay_customer(self, user_id, user_type):
        """ Amount Paid TO Customer """
        if user_type == 'Retailer':
            domain = ['|',('user_id', '=', user_id),('user_id2', '=', user_id),
                        ('mobile_bool', '=', True),
                        ('retailer_scanned', '=', True),]

            amount_total = [sum(x.amount for x in request.env['barcode.marketing.line'].sudo().search(domain) )]

            return {'success': amount_total or 0.0, 'error': None}

    @http.route('/wmvdapi/received_from_distributor', auth='user', methods=["POST"], type="json")
    def received_from_distributor(self, user_id, user_type):
        """ Amount Received From Distributor """
        if user_type == 'Retailer':
            domain = ['|',('user_id', '=', user_id),('user_id2', '=', user_id),
                        ('mobile_bool', '=', True),
                        ('retailer_scanned', '=', True),
                        '|',('distributor_paid_bool', '=', True),('distributor_paid_bool2', '=', True)]

            amount_total = [sum(x.amount for x in request.env['barcode.marketing.line'].sudo().search(domain) )]

            return {'success': amount_total or 0.0, 'error': None}

    @http.route('/wmvdapi/to_receive_from_distributor', auth='user', methods=["POST"], type="json")
    def to_receive_from_distributor(self, user_id, user_type):
        """ Amount yet to be Received From Distributor """
        if user_type == 'Retailer':
            domain = ['|',('user_id', '=', user_id),('user_id2', '=', user_id),
                        ('mobile_bool', '=', True),
                        ('retailer_scanned', '=', True),
                        '|',('distributor_paid_bool', '=', False),('distributor_paid_bool2', '=', False),]

            amount_total = [sum(x.amount for x in request.env['barcode.marketing.line'].sudo().search(domain))]

            return {'success': amount_total or 0.0, 'error': None}

    @http.route('/wmvdapi/today_scan_coupons_count', auth='user', methods=["POST"], type="json")
    def today_scan_coupons_count(self, user_id):
        """ Today Scans Count By User """
        domain = ['|',('user_id', '=', user_id),('user_id2', '=', user_id),'|',
                    ('updated_date', '=', date.today()),
                    ('scanned_date2', '=', date.today())
                ]

        coupon_scanned = request.env['barcode.marketing.line'].sudo().search_count(domain)

        return {'success': coupon_scanned, 'error': None}


    @http.route('/wmvdapi/distributor_count', auth='user', methods=["POST"], type="json")
    def distributor_count(self, user_id):
        """ Distributor Count By User """
        domain = [('retailer_user_id', '=', user_id)]

        distributor_count = request.env['wp.retailer'].sudo().search_count(domain)

        return {'success': distributor_count, 'error': None}

    @http.route('/wmvdapi/pay_retailer', auth='user', methods=["POST"], type="json")
    def pay_retailer(self, amount, payment_mode=False):
        """ Amount Paid TO Customer """
        if user_type == 'Distributor':
            domain = [('user_id', '=', user_id),
                        ('mobile_bool', '=', True),
                        ('retailer_scanned', '=', True),]

            amount_total = [x.amount for x in request.env['barcode.marketing.line'].search(domain)]

            return {'success': amount_total, 'error': None}