from odoo import http
from odoo.http import request
import json
import xmlrpc, xmlrpc.client
from odoo.addons.web.controllers.main import ensure_db, Session
from odoo.tools.translate import _
from datetime import datetime, timedelta, date


class QrCodeScanning(http.Controller):

    @http.route('/wmvdapi/push_qrcoupon', auth='user', methods=["POST"], type="json")
    def push_coupon(self, coupon, user_id, user_type, distributor_id=False):

        print "ggggggggggggggggggggggggggggggg" , coupon, distributor_id, user_id, user_type
        resp = request.env['barcode.marketing.check'].sudo().check_mobile_coupon(coupon, user_id, user_type, distributor_id)
        print("fffffffffffffffffffffffffffffff", resp, type(resp))
        if isinstance(resp, str):
            return {'success': None, 'error': resp}
            
        else:
            return {'success': resp, 'error': None}


        # try:
        #     print "ggggggggggggggggggggggggggggggg" , coupon, distributor_id, user_id
        #     resp = request.env['barcode.marketing.check'].sudo().check_mobile_coupon(coupon, user_id , distributor_id)
        #     # return {'status': 200, 'response': resp, 'message': 'Coupon Scanned Succesfully'}
        #     return {'success': resp, 'error': None}
        # except:
        #     return {'success': None, 'error': 'Invalid Coupon. Coupon Not Present'}
        #     # return json.dumps({'Error':'Invalid Coupon. Coupon Not Present'})


    @http.route('/wmvdapi/pay_customer', auth='user', methods=["POST"], type="json")
    def pay_customer(self, user_id, user_type):
        """ Amount Paid TO Customer """
        if user_type == 'Retailer':
            domain = [('user_id', '=', user_id),
                        ('mobile_bool', '=', True),
                        ('retailer_scanned', '=', True),
                    ]

            amount_total = [sum(x.amount for x in request.env['barcode.marketing.line'].sudo().search(domain) )]

            return {'success': amount_total or 0.0, 'error': None}

    @http.route('/wmvdapi/received_from_distributor', auth='user', methods=["POST"], type="json")
    def received_from_distributor(self, user_id, user_type):
        """ Amount Received From Distributor """
        if user_type == 'Retailer':
            domain = [('user_id', '=', user_id),
                        ('mobile_bool', '=', True),
                        ('retailer_scanned', '=', True),
                        ('distributor_paid_bool', '=', True),
                    ]

            amount_total = [sum(x.amount for x in request.env['barcode.marketing.line'].sudo().search(domain) )]

            return {'success': amount_total or 0.0, 'error': None}

    @http.route('/wmvdapi/to_receive_from_distributor', auth='user', methods=["POST"], type="json")
    def to_receive_from_distributor(self, user_id, user_type):
        """ Amount yet to be Received From Distributor """
	print "11111111111111", user_id, user_type
        if user_type == 'Retailer':
            domain = [('user_id', '=', user_id),
                        ('mobile_bool', '=', True),
                        ('retailer_scanned', '=', True),
                        ('distributor_paid_bool', '=', False),
                    ]

            amount_total = [sum(x.amount for x in request.env['barcode.marketing.line'].sudo().search(domain))]
	    print "222222222222222222" ,amount_total

            return {'success': amount_total or 0.0, 'error': None}


    @http.route('/wmvdapi/today_scan_coupons', auth='user', methods=["POST"], type="json")
    def today_scan_coupons(self, user_id):
        """ Today Scans By User """
        data = {}
        today_scan_coupons= []
        domain = [('user_id', '=', user_id),
                    ('updated_date', '=', date.today()),
                ]

        coupon_scanned = request.env['barcode.marketing.line'].sudo().search(domain)

        for res in coupon_scanned:
            data = {
                    'coupon': res.name,
                    'date': res.updated_date,
                    'distributor' : res.partner_id.name, 
                    'user' : res.user_id.name, 
                    'amount' : res.amount,
                }
            today_scan_coupons.append((data))

        return {'success': today_scan_coupons, 'error': None}


    @http.route('/wmvdapi/all_scan_coupons', auth='user', methods=["POST"], type="json")
    def all_scan_coupons(self, user_id):
        """ All Scans By User """
        data = {}
        all_scan_coupons= []
        domain = [('user_id', '=', user_id),]
        coupon_scanned = request.env['barcode.marketing.line'].sudo().search(domain)

        for res in coupon_scanned:
            data = {
                    'coupon': res.name,
                    'date': res.updated_date,
                    'distributor' : res.partner_id.name, 
                    'user' : res.user_id.name, 
                    'amount' : res.amount,
                }
            all_scan_coupons.append((data))

        return {'success': all_scan_coupons, 'error': None}

    @http.route('/wmvdapi/today_scan_coupons_count', auth='user', methods=["POST"], type="json")
    def today_scan_coupons_count(self, user_id):
        """ Today Scans Count By User """


        domain = [('user_id', '=', user_id),
                  ('updated_date', '=', date.today()) ]

        coupon_scanned = request.env['barcode.marketing.line'].sudo().search_count(domain)

        return {'success': coupon_scanned, 'error': None}

    @http.route('/wmvdapi/distributor_count', auth='user', methods=["POST"], type="json")
    def distributor_count(self, user_id):
        """ Distributor Count By User """
        domain = [('retailer_user_id', '=', user_id)]

        distributor_count = request.env['wp.retailer'].sudo().search_count(domain)

        return {'success': distributor_count, 'error': None}


    @http.route('/wmvdapi/get_retailer', auth='user', methods=["GET"], type="json")
    def get_retailer(self, partner_id):
        """ All Retailers of Distributor """


        domain = [('wp_distributor_id', '=', partner_id),]
        partner_rec = request.env['res.partner'].sudo().search(domain)

        if partner_rec :
            partner = []

            for rec in partner_rec:
                base_url = request.env['ir.config_parameter'].sudo().get_param('web.base.url')
                image_url_128 = base_url + '/web/image?' + 'model=res.partner&id=' + str(rec.id) + '&field=image'
                vals = {
                    'id': rec.id,
                    'name': rec.name,
                    'mobile': rec.mobile,
                    'email' : rec.email,
                    'image' : image_url_128,
                    'address' : ((rec.street + ', ') if rec.street else ' ' ) + \
                                ((rec.street2+ ', ') if rec.street2 else ' ' )  + \
                                ((rec.city + ', ') if rec.city else ' ' ) + \
                                ((rec.zip + ', ') if rec.zip else ' ' ) + \
                                ((rec.state_id.name + ', ') if rec.state_id else ' ' ) + \
                                ((rec.country_id.name + ', ') if rec.country_id else ' ' )

                }
                partner.append(vals)
            # data = {'status': 200, 'response': partner, 'message': 'partner(s) returned'}
            return {'success': partner, 'error': None}
            # return data
        else:
            return {'success': None, 'error':'No Retailers Found'}


    @http.route('/wmvdapi/pay_retailer', auth='user', methods=["POST"], type="json")
    def pay_retailer(self, amount, payment_mode=False):
        """ Amount Paid TO Customer """
        if user_type == 'Distributor':
            domain = [('user_id', '=', user_id),
                        ('mobile_bool', '=', True),
                        ('retailer_scanned', '=', True),
                    ]

            amount_total = [x.amount for x in request.env['barcode.marketing.line'].search(domain)]

            return {'success': amount_total, 'error': None}
