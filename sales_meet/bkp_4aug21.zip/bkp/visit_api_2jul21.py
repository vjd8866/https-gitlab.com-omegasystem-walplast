from odoo import http
from odoo.http import request
import json
import time
import xmlrpc, xmlrpc.client
from odoo.addons.web.controllers.main import ensure_db, Session
from odoo.tools.translate import _
from datetime import datetime, timedelta, date
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT
from odoo.http import Response


DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"
mainfields = ['id', 'name']

headers = {
    'Content-Type': 'application/json',
}

# headers = {
#     'Content-Type': 'message/http',
# }



class WpVisitController(http.Controller):

    @http.route('/wmvdapi/create_visit', methods=["POST"], type='json', auth='user')
    def create_visit(self, visit_id=None, user_id=None, lead_id=None, retailer_id=None, distributor_id=None, stage_id=None, 
        activity_id=None, date=None, started_at=None, latitude=None, longitude=None, description=None, address=None):
        print("------------/wmvdapi/create_visit -----------", user_id)
        # {"jsonrpc":"2.0","params":{"user_id":  1088, "lead_id": None, "retailer_id" :None, "distributor_id":None,
         # "stage_id":None, "activity_id": None, "date":None, "started_at": None}}
        lead = retailer = partner = stage = activity = ''
        if lead_id: lead = request.env['crm.lead'].sudo().search([('id', '=', lead_id)])

        if retailer_id: retailer = request.env['wp.retailer'].sudo().search([('id', '=', retailer_id)])

        if distributor_id: partner = request.env['res.partner'].sudo().search([('id', '=', distributor_id)])

        if stage_id: stage = request.env['crm.stage'].sudo().search([('id', '=', stage_id)])

        if activity_id: activity = request.env['crm.activity'].sudo().search([('id', '=', activity_id)])

        users_rec = request.env['res.users'].sudo().search([('id', '=', user_id),('active', '=', True)], limit=1).name

        meet_name = "Meeting With " + (lead.name if lead_id else  partner.name if distributor_id else retailer.name if  retailer_id else '')
        ischeck = 'lead' if lead_id else  'customer' if distributor_id else 'Retailer' if  retailer_id else ''
       
        calendar_event_vals = {
                'name': meet_name,
                'start_datetime': started_at,
                'stop_datetime': started_at,
                'start': started_at,
                'stop': started_at,
                'allday': False,
                'show_as': 'busy',
                'meeting_type': 'check-in',
                'partner_ids': [(6, 0, [])] or '',
                'stage_id': stage.id or '',
                'categ_id': activity.id or '',
                'user_id': user_id,
                'ischeck': ischeck,
                'partner_id': partner.id if distributor_id else '',
                'lead_id': lead.id if lead_id else '',
                'retailer_id': retailer.id if retailer_id else '',
                'status': 'close',
                "description": description,
                'mobile_id': visit_id,
                'checkin_lattitude': latitude,
                'checkin_longitude': longitude,
                'reverse_location': address,
            }

        event = request.env['calendar.event'].sudo().create(calendar_event_vals)

        vals = {
                "id": visit_id,
                "stage_id": stage.id or None,
                "stage": stage.name or '',
                "activity_id": activity.id or None,
                "activity": activity.name or '',
                "time": started_at,
                "user_id": user_id,
                "user": users_rec,
                "name": meet_name,
                'distributor_id': partner.id if distributor_id else None,
                'lead_id': lead.id if lead_id else None,
                'retailer_id': retailer.id if retailer_id else None,
                'distributor_name': partner.name if distributor_id else '',
                'lead_name': lead.name if lead_id else '',
                'retailer_name': retailer.name if retailer_id else '',
                "meeting_type": "check-in",
                "ischeck": ischeck,
                "type": "check-in",
                "reason" : description,
                "lat": latitude,
                "long": longitude,
                "portal_id" : event.id,
                'address': address,
        }

        response = {'visit' : vals}
        return {'success': response, 'error': None}

    @http.route('/wmvdapi/get_user_visits', auth='user', methods=["POST"], type='json')
    def get_user_visits(self, user_id=None, date=None):
        print("------------/wmvdapi/get_user_visits -----------")
        if date:
            domain = [('user_id', '=', user_id),('meeting_type','=','check-in'),('expense_date','=',date)]
        else:
            domain = [('user_id', '=', user_id),('meeting_type','=','check-in')]

        calendar_rec = request.env['calendar.event'].sudo().search(domain)
        calendar_list = []
        if calendar_rec:
            for res in calendar_rec:
                vals = {
                        "id": res.mobile_id,
                        "stage_id": res.stage_id.id or None,
                        "activity_id": res.categ_id.id or None,
                        "stage": res.stage_id.name or '',
                        "activity": res.categ_id.name or '',
                        "time": res.start,
                        "user_id": res.user_id.id,
                        "user": res.user_id.name,
                        "name": res.name,
                        'distributor_id': res.partner_id.id or None,
                        'lead_id': res.lead_id.id or None,
                        'retailer_id': res.retailer_id.id or None,
                        'distributor_name': res.partner_id.name or '',
                        'lead_name': res.lead_id.name or '',
                        'retailer_name': res.retailer_id.name or '',
                        "meeting_type": "check-in",
                        "partner_type": res.ischeck,
                        "type": "check-in",
                        "reason" : res.description,
                        "lat": res.checkin_lattitude,
                        "long": res.checkin_longitude,
                        "portal_id" : res.id,
                        'address': res.reverse_location,
                }
                calendar_list.append(vals)

            response = {'count' : len(calendar_rec), 'list': calendar_list}
            return {'success': response, 'error': None}
        else:
            return {'success': None, 'error':'No Records Found'}


    @http.route('/wmvdapi/get_crm_activity', auth='user', methods=["POST"], type='json')
    def get_crm_activity(self):
        print("------------/wmvdapi/get_crm_activity -----------")
        result = request.env['crm.activity'].search([]).read(mainfields)
        activity = {'success': result or {}, 'error': None}
        # return json.dumps(activity)
        # return Response(json.dumps(activity),headers=headers)
        return activity


    @http.route('/wmvdapi/get_crm_stage', auth='user', methods=["POST"], type='json')
    def get_crm_stage(self):
        print("------------/wmvdapi/get_crm_stage -----------")
        result = request.env['crm.stage'].search([]).read(mainfields)
        stage = {'success': result or {}, 'error': None}
        # return json.dumps(stage)
        # return Response(json.dumps(stage),headers=headers)
        return stage

    @http.route('/wmvdapi/get_salesperson_lead', auth='user', methods=["POST"], type='json')
    def get_salesperson_lead(self, user_id=None):
        start = time.time()
        print("------------/wmvdapi/get_salesperson_lead -----------", user_id)
        state_id = request.env['hr.employee'].sudo().search([('user_id', '=', user_id),('active', '=', True)], limit=1).state_id.id
        result = request.env['crm.lead'].search([('state_id', '=', state_id),('state_id', '!=', False),]).read(mainfields)
        end = time.time()
        print "------------- END get_assigned_retailer_list -------", end-start
        return {'success': result or {}, 'error': None}


    @http.route('/wmvdapi/get_assigned_retailer_list', methods=["POST"], type='json', auth='user')
    def get_assigned_retailer_list(self, user_id=None):
        start = time.time()
        print("------------/wmvdapi/get_assigned_retailer_list -----------", user_id)

        manager_id = request.env['hr.employee'].sudo().search([('user_id', '=', user_id),('active', '=', True)], limit=1).id
        if manager_id:
            response = self.assigned_retailer_list(manager_id, user_id, retailers=[])

            end = time.time()
            print "------------- END get_assigned_retailer_list -------", end-start

            if response:
                return {'success': response, 'error': None}
            else:
                return {'success': None, 'error':'No Retailer Found'}

        else:
            return {'success': None, 'error':'No Retailer Found'}


    def assigned_retailer_list(self,manager_id=False, user_id=False, retailers=[]):
        retailers_rec = request.env['wp.retailer'].sudo().search([('salesperson_id', '=', user_id), ('salesperson_id', '!=', False),
                                                                  ('active', '=', True)]).read(mainfields)

        if retailers_rec : retailers.extend(retailers_rec)

        subordinate_ids = request.env['hr.employee'].sudo().search([('parent_id','=', manager_id)])
        if subordinate_ids :
            for res in subordinate_ids:
                self.assigned_retailer_list(res.id, res.user_id.id, retailers)

        response = {'count' : len(retailers), 'retailers': retailers}
        return response



    @http.route('/wmvdapi/get_salesperson_distributor_list', methods=["POST"], type='json', auth='user')
    def get_salesperson_distributor_list(self, user_id=None):
        start = time.time()
        print("------------/wmvdapi/get_salesperson_distributor_list -----------", user_id)

        manager_id = request.env['hr.employee'].sudo().search([('user_id', '=', user_id),('active', '=', True)], limit=1).id
        if manager_id:
            response = self.assigned_distributor_list(manager_id, user_id, distributors=[])

            end = time.time()
            print "------------- END get_salesperson_distributor_list -------", end-start

            if response:
                return {'success': response, 'error': None}
            else:
                return {'success': None, 'error':'No Distributors Found'}

        else:
            return {'success': None, 'error':'No Distributors Found'}


    def assigned_distributor_list(self,manager_id=False, user_id=False, distributors=[]):
        partner_rec = request.env['res.partner'].sudo().search([('user_id', '=', user_id), ('user_id', '!=', False),
                                                                ('active', '=', True)]).read(mainfields)

        if partner_rec : distributors.extend(partner_rec)

        subordinate_ids = request.env['hr.employee'].sudo().search([('parent_id','=', manager_id)])
        if subordinate_ids :
            for res in subordinate_ids:
                self.assigned_distributor_list(res.id, res.user_id.id, distributors)

        response = {'count' : len(distributors), 'distributors': distributors}
        return response


    # @http.route(['/wmvdapi/get_crm_stage', '/wmvdapi/get_crm_stage/<int:id>'], auth='user', methods=["POST"], type='json')
    # def get_crm_stage(self, stage_id=None):
    #     print("------------/wmvdapi/get_crm_stage -----------", stage_id)
    #     mainfields = ['id', 'name']
    #     if stage_id:
    #         result = request.env['crm.stage'].browse(stage_id).read(mainfields)
    #         stage = result and result[0] or {}
    #         return {'success': stage, 'error': None}
    #     else:
    #         result = request.env['crm.stage'].search([]).read(mainfields)
    #         stage = result or {}
    #         return {'success': stage, 'error': None}



    # @http.route(['/wmvdapi/get_crm_activity', '/wmvdapi/get_crm_activity/<int:id>'], auth='user', methods=["POST"], type='json')
    # def get_crm_activity(self, activity_id=None):
    #     print("------------/wmvdapi/get_crm_activity -----------", activity_id)
    #     mainfields = ['id', 'name']
    #     if activity_id:
    #         result = request.env['crm.activity'].browse(activity_id).read(mainfields)
    #         activity = result and result[0] or {}
    #         return {'success': activity, 'error': None}
    #     else:
    #         result = request.env['crm.activity'].search([]).read(mainfields)
    #         activity = result or {}
    #         return {'success': activity, 'error': None}


    # @http.route('/wmvdapi/get_crm_activity', auth='user', methods=["GET"], type='http')
    # def get_crm_activity(self):
    #     print("------------/wmvdapi/get_crm_activity -----------")
    #     result = request.env['crm.activity'].search([]).read(mainfields)
    #     activity = {'success': result or {}, 'error': None}
    #     # return json.dumps(activity)
    #     return Response(json.dumps(activity),headers=headers)


    # @http.route('/wmvdapi/get_crm_stage', auth='user', methods=["GET"], type='http')
    # def get_crm_stage(self):
    #     print("------------/wmvdapi/get_crm_stage -----------")
    #     result = request.env['crm.stage'].search([]).read(mainfields)
    #     stage = {'success': result or {}, 'error': None}
    #     # return json.dumps(stage)
    #     return Response(json.dumps(stage),headers=headers)

    # @http.route(['/wmvdapi/get_salesperson_lead', '/wmvdapi/get_salesperson_lead/<int:id>'], auth='user', methods=["POST"], type='json')
    # def get_salesperson_lead(self, user_id=None, lead_id=None, search_query=None):
    #     print("------------/wmvdapi/get_salesperson_lead -----------", user_id, lead_id)
    #     if user_id:
    #         state_id = request.env['hr.employee'].sudo().search([('user_id', '=', user_id),('active', '=', True)], limit=1).state_id.id
    #     mainfields = ['id', 'name', 'state_id']
    #     if lead_id:
    #         result = request.env['crm.lead'].browse(lead_id).read(mainfields)
    #         lead = result and result[0] or {}
    #         return {'success': lead, 'error': None}
    #     elif search_query:
    #         result = request.env['crm.lead'].search([('state_id', '=', state_id),
    #             ('state_id', '!=', False),
    #             ('name', 'ilike', search_query)]).read(mainfields)
    #         lead = result or {}
    #         return {'success': lead, 'error': None}

    #     else:
    #         result = request.env['crm.lead'].search([('state_id', '=', state_id),('state_id', '!=', False),]).read(mainfields)
    #         lead = result or {}
    #         return {'success': lead, 'error': None}

    # def assigned_retailer_list(self,manager_id=False, user_id=False, search_query=False,  retailers=[]):
    #     if search_query:
    #         domain = [('salesperson_id', '=', user_id),
    #                     ('salesperson_id', '!=', False),
    #                     ('active', '=', True),
    #                     ('name', 'ilike', search_query)]
    #     else:
    #         domain = [('salesperson_id', '=', user_id),
    #                   ('salesperson_id', '!=', False),
    #                   ('active', '=', True)]

    #     partner_rec = request.env['wp.retailer'].sudo().search(domain)   

    #     if partner_rec :

    #         for rec in partner_rec:
    #             retailer_user_id = request.env['res.users'].sudo().search([('partner_id','=',rec.retailer_partner_id.id)], limit=1)
    #             vals = {
    #                 'id': rec.id,
    #                 'retailer_user_id': retailer_user_id.id or '',
    #                 'name': rec.name,
    #                 'mobile': rec.mobile or '',
    #                 'email' : rec.email or '',
    #                 'salesperson_id' : rec.salesperson_id.id,
    #                 'salesperson_name' : rec.salesperson_id.name,
    #                 'state_id' : rec.state_id.id or '',
    #                 'state' : rec.state_id.name or '',
    #                 'address' : ((rec.street + ', ') if rec.street else '' ) + \
    #                             ((rec.street2+ ', ') if rec.street2 else '' )  + \
    #                             ((rec.city + ', ') if rec.city else '' ) + \
    #                             ((rec.zip + ', ') if rec.zip else '' ) + \
    #                             ((rec.state_id.name + ', ') if rec.state_id else '' ) + \
    #                             ((rec.country_id.name + ', ') if rec.country_id else '' )

    #             }
    #             retailers.append(vals)

    #     subordinate_ids = request.env['hr.employee'].sudo().search([('parent_id','=', manager_id)])
    #     if subordinate_ids :
    #         for res in subordinate_ids:
    #             print("aaaaaaaaaaaa--------------------", res.id, res.user_id.id, search_query)
    #             self.assigned_retailer_list(res.id, res.user_id.id, search_query, retailers)

    #     response = {'count' : len(retailers), 'retailers': retailers}
    #     return response
