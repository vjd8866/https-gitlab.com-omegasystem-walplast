from odoo import http
from odoo.http import request
import json
import xmlrpc, xmlrpc.client
from odoo.addons.web.controllers.main import ensure_db, Session
from odoo.tools.translate import _
import time
from datetime import datetime, timedelta, date
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT

DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"

class EmployeeCouponCNReceivedDashboard(http.Controller):

	@http.route('/wmvdapi/get_salesperson_distributor', methods=["POST"], type='json', auth='user')
	def get_salesperson_distributor(self, user_id=None):
		print("------------/wmvdapi/get_salesperson_distributor -----------", user_id)
		domain = [('user_id', '=', user_id),('active', '=', True),('customer', '=', True)]
		partner_rec = request.env['res.partner'].sudo().search(domain)

		if partner_rec :
			distributor_count = len(partner_rec)
			partner = []

			for rec in partner_rec:
				base_url = request.env['ir.config_parameter'].sudo().get_param('web.base.url')
				image_url_128 = base_url + '/web/image?' + 'model=res.partner&id=' + str(rec.id) + '&field=image'
				distributor_user_id = request.env['res.users'].sudo().search([('partner_id','=',rec.id)], limit=1)

				dist_dashboard = self.salesperson_distributor_dashboard(rec.id, distributor_list=True)
				vals = {
						'id': rec.id,
						'distributor_user_id': distributor_user_id.id or '',
						'name': rec.name,
						'mobile': rec.mobile or '',
						'email' : rec.email or '',
						'image' : image_url_128,
						'address' : ((rec.street + ', ') if rec.street else '' ) + \
									((rec.street2+ ', ') if rec.street2 else '' )  + \
									((rec.city + ', ') if rec.city else '' ) + \
									((rec.zip + ', ') if rec.zip else '' ) + \
									((rec.state_id.name + ', ') if rec.state_id else '' ) + \
									((rec.country_id.name + ', ') if rec.country_id else '' ),
					}
				if dist_dashboard:
					vals['amount'] = dist_dashboard
				else:
					dist_dashboard=  {
						"credit_received": 0,
						"payment_pending": 0,
						"credit_pending": 0,
						"self_scanned": 0
					}
					vals['amount'] = dist_dashboard
				partner.append(vals)

			response = {'count' : distributor_count, 'list': partner}
			return {'success': response, 'error': None}
		else:
			return {'success': None, 'error':'No Distributors Found'}


	@http.route('/wmvdapi/salesperson_distributor_dashboard', auth='user', methods=["POST"], type="json")
	def salesperson_distributor_dashboard(self, distributor_id, distributor_list=False):
		""" Salesperson Distributor Dashboard """
		print("------------/wmvdapi/salesperson_distributor_dashboard -----------", distributor_id)

		credit_received_domain = [('status', '=', 'paid'), ('distributor_id', '=', distributor_id)]
		credit_pending_domain = [('status', '=', 'pending'), ('distributor_id', '=', distributor_id)]
		self_scanned_domain = [('distributor_id', '=', distributor_id),('retailer_id', '=', distributor_id)]

		payment_paid_domain = [('status', '=', 'paid'), 
								('distributor_id', '=', distributor_id),
								('retailer_id', '!=', distributor_id)]

		cn_received_amount = [sum(x.amount for x in request.env['wp.coupon.credit'].sudo().search(credit_received_domain))]
		cn_pending_amount = [sum(x.amount for x in request.env['wp.coupon.credit'].sudo().search(credit_pending_domain))]
		pmt_paid_amount = [sum(x.amount for x in request.env['wp.coupon.payment'].sudo().search(payment_paid_domain))]
		self_scanned_amount = [sum(x.amount for x in request.env['wp.coupon.payment'].sudo().search(self_scanned_domain))]

		response = {'credit_received' : (cn_received_amount[0] if cn_received_amount else 0)  or 0,
					'credit_pending' : (cn_pending_amount[0] if cn_pending_amount else 0)  or 0,
					'payment_pending' : (pmt_paid_amount[0] if pmt_paid_amount else 0)  or 0,
					'self_scanned' : (self_scanned_amount[0] if self_scanned_amount else 0)  or 0,
				}

		if distributor_list:
			return response

		return {'success': response, 'error': None}


	@http.route('/wmvdapi/get_subordinate_list', methods=["POST"], type='json', auth='user')
	def get_subordinate_list(self, user_id=None):
		start = time.time()
		print("------------/wmvdapi/get_subordinate_list -----------", user_id)

		manager_id = request.env['hr.employee'].sudo().search([('user_id', '=', user_id),('active', '=', True)], limit=1).id
		if manager_id:
			response = self.subordinate_list(manager_id, employees=[])

			end = time.time()
			print "------------- END get_subordinate_list -------", end-start

			if response:
				return {'success': response, 'error': None}
			else:
				return {'success': None, 'error':'No Subordinates Found'}

		else:
			return {'success': None, 'error':'No Subordinates Found'}


	def subordinate_list(self,manager_id=False, employees=[]):
		subordinate_ids = request.env['hr.employee'].sudo().search([('parent_id','=', manager_id)])
		if subordinate_ids :
			for rec in subordinate_ids:
				jl = request.env['wp.salesperson.journey'].sudo().search([('user_id', '=', rec.user_id.id),
					('date','=',date.today())], limit=1)

				journey = {
						"id" : jl.id or '',
						"date": jl.date or '',
						"started_at" : jl.started_at or '',
						"ended_at" : jl.ended_at or '',
				}
				
				vals = {
					'id': rec.id,
					'user_id': rec.user_id.id,
					'name': rec.name,			
					'mobile': rec.mobile_phone or "",
					'email' : rec.work_email or "",
					'designation': rec.job_id.name or "",
					'user_type' : rec.user_id.wp_user_type_id.name or "",
					'manager_id': rec.parent_id.user_id.id,
					'manager': rec.parent_id.user_id.name,
					"journey": journey,
				}
				employees.append(vals)

				self.subordinate_list(rec.id, employees)

			response = {'count' : len(employees), 'employees': employees}
			return response


	# @http.route('/wmvdapi/get_subordinate_list', methods=["POST"], type='json', auth='user')
	# def get_subordinate_list(self, user_id=None):
	# 	print("------------/wmvdapi/get_subordinate_list -----------", user_id)
		
	# 	manager_id = request.env['hr.employee'].sudo().search([('user_id', '=', user_id),('active', '=', True)], limit=1).id

	# 	subordinate_ids = request.env['hr.employee'].sudo().search([('parent_id','=', manager_id.id)])
	# 	if subordinate_ids :
	# 		subordinate_count = len(subordinate_ids)
	# 		employees = []

	# 		for rec in subordinate_ids:
	# 			emp_user_id = request.env['res.users'].sudo().search([('id','=',rec.user_id.id)], limit=1)

	# 			jl = request.env['wp.salesperson.journey'].sudo().search([('user_id', '=', emp_user_id.id),
	# 				('date','=',date.today())], limit=1)
	# 			journey = {
	# 					"id" : jl.id or "",
	# 					"date": jl.date or "",
	# 					"started_at" : jl.started_at or "",
	# 					"ended_at" : jl.ended_at or "",
	# 			}

	# 			vals = {
	# 				'id': rec.id,
	# 				'user_id': emp_user_id.id,
	# 				'manager_id': user_id,
	# 				'manager': manager_id.name,
	# 				'name': rec.name,
	# 				'mobile': rec.mobile_phone or '',
	# 				'email' : rec.work_email or '',
	# 				'designation': rec.job_id.name,
	# 				"journey": journey,
	# 			}
	# 			employees.append(vals)

	# 		response = {'count' : subordinate_count, 'employees': employees}
	# 		return {'success': response, 'error': None}
	# 	else:
	# 		return {'success': None, 'error':'No Subordinates Found'}
