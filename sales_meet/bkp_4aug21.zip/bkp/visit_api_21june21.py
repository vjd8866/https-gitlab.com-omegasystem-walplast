from odoo import http
from odoo.http import request
import json
import xmlrpc, xmlrpc.client
from odoo.addons.web.controllers.main import ensure_db, Session
from odoo.tools.translate import _
from datetime import datetime, timedelta, date
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT

DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"

class WpVisitController(http.Controller):

    @http.route('/wmvdapi/create_visit', methods=["POST"], type='json', auth='user')
    def create_visit(self, user_id=None, lead_id=None, retailer_id=None, distributor_id=None, stage_id=None, 
        activity_id=None, date=None, started_at=None):
        print("------------/wmvdapi/create_visit -----------", user_id)
        # {"jsonrpc":"2.0","params":{"user_id":  1088, "lead_id": None, "retailer_id" :None, "distributor_id":None,
         # "stage_id":None, "activity_id": None, "date":None, "started_at": None}}
        if lead_id:
            lead = request.env['crm.lead'].sudo().search([('id', '=', lead_id)])

        if retailer_id:
            retailer = request.env['wp.retailer'].sudo().search([('id', '=', retailer_id)])

        if distributor_id:
            partner = request.env['crm.lead'].sudo().search([('id', '=', distributor_id)])

        if stage_id:
            stage = request.env['crm.stage'].sudo().search([('id', '=', stage_id)])

        if activity_id:
            activity = request.env['crm.activity'].sudo().search([('id', '=', activity_id)])

        name = "Meeting With " + lead.name if lead_id else  partner.name if distributor_id else retailer.name if  retailer_id else ''

        ischeck = 'lead' if lead_id else  'customer' if distributor_id else 'Retailer' if  retailer_id else ''

        print("aaaaaaaaaaaa", name, lead_id , distributor_id, retailer_id)
        
        calendar_event_vals = {
                'name': name,
                'start_datetime': started_at,
                'stop_datetime': started_at,
                'start': started_at,
                'stop': started_at,
                'allday': False,
                'show_as': 'busy',
                'meeting_type': 'check-in',
                'partner_ids': [(6, 0, [])] or '',
                'stage_id': stage.id or '',
                'categ_id': activity.id,
                'user_id': user_id,
                'ischeck': ischeck,
                'partner_id': partner.id if distributor_id else '',
                'lead_id': lead.id if lead_id else '',
                'retailer_id': retailer.id if retailer_id else '',
            }

        # self.status = 'close'
        event = request.env['calendar.event'].sudo().create(calendar_event_vals)

        vals = {

        }


        response = {'visit' : calendar_event_vals}
        return {'success': response, 'error': None}



    @http.route(['/wmvdapi/get_crm_activity', '/wmvdapi/get_crm_activity/<int:id>'], auth='user', methods=["POST"], type='json')
    def get_crm_activity(self, activity_id=None):
        print("------------/wmvdapi/get_crm_activity -----------", activity_id)
        mainfields = ['id', 'name']
        if activity_id:
            result = request.env['crm.activity'].browse(activity_id).read(mainfields)
            activity = result and result[0] or {}
            return {'success': activity, 'error': None}
        else:
            result = request.env['crm.activity'].search([]).read(mainfields)
            activity = result or {}
            return {'success': activity, 'error': None}


    @http.route(['/wmvdapi/get_crm_stage', '/wmvdapi/get_crm_stage/<int:id>'], auth='user', methods=["POST"], type='json')
    def get_crm_stage(self, stage_id=None):
        print("------------/wmvdapi/get_crm_stage -----------", stage_id)
        mainfields = ['id', 'name']
        if stage_id:
            result = request.env['crm.stage'].browse(stage_id).read(mainfields)
            stage = result and result[0] or {}
            return {'success': stage, 'error': None}
        else:
            result = request.env['crm.stage'].search([]).read(mainfields)
            stage = result or {}
            return {'success': stage, 'error': None}